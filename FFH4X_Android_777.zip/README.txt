FFH4X. - Projeto Android demonstrativo

Como gerar o APK:
1. Extraia o ZIP em um computador.
2. Instale/abra Android Studio e escolha Open.
3. Selecione a pasta FFH4X_Android extraída.
4. Aguarde a sincronização do Gradle.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de depuração será gerado em app/build/outputs/apk/debug/app-debug.apk.

Observação: este app contém apenas uma interface WebView local. O botão INJETAR é uma animação demonstrativa de 5 segundos; não injeta código nem interage com Free Fire.
